package customer.model.service;

public class GnaService {

}
