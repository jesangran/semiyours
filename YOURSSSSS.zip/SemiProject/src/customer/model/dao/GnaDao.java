package customer.model.dao;

public class GnaDao {

}
