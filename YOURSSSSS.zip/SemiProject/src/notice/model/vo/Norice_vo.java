package notice.model.vo;

import java.sql.Date;

public class Norice_vo {
	private int nNo; // 공지사항 글번호
	private String nTitle; // 공지사항 제목
	//private Date; // 공지사항 작성일 // 다른곳에서 불러오기도 고려
	private int nCount; // 조회수
	// 작성자 즉, 관리자이므로 불러오는걸로 고려
}
